A Pen created at CodePen.io. You can find this one at http://codepen.io/FrankFitzGerald/pen/LAbfm.

 Sakura animation using WebGL. No images are used. The framerate might be slow or the demo might not play at all in some older systems so you can watch this video: http://www.screenr.com/BFZ8. Let me make it clear that I did not make this and just thought is was very cool and wanted to share it.